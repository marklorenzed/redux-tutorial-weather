import { FETCH_WEATHER } from "../actions/index";

export default function(state = [], action) {
    switch (action.type) {
    case FETCH_WEATHER:

        // state.push(action.payload.data) <<-- wrong, dont manipulate state directly
        
        // return state.concat([action.payload.data]);
        //returns a new instance of state
        //or use es6 
        return [ action.payload.data, ...state];
    }


    return state;
}